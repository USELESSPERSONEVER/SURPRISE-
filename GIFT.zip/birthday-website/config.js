/* Edit this file only. Put your files in assets/ and match the paths below. */
window.birthdayConfig = {
  name: "Shaima",
  nickname: "chudail",
  yourName: "Asif",

  // Site stays locked until this moment (IST = +05:30).
  unlockAt: "2026-09-29T00:00:00+05:30",

  backgroundMusic: "assets/audio/background.mp3",

  // [LETTER] -> replace with your letter. Line breaks are kept.
  letter: `Dear Shaima 🫂,

Happy Birthday, Faudi—or Khebdi, or Chudail, take your pick since all of them suit you equally well. Another year of you existing in this world, and somehow I still haven’t run away, which is honestly impressive. I still remember that peaceful day at Juhu Beach after our long, unnecessary argument, walking along the salty shore and laughing too hard at stupid things like the fight never even happened. Then there was Cafe 9 in 11th grade on your birthday—us, some cake, and Ziya sitting there like she’d been part of the group forever. Funny how people disappear, but that evening still sits somewhere in my head because you were happy that day... annoying, but happy.

Now let’s talk about the big one: the day you decided to completely destroy my life. I had a flight, a plan, and a dream job waiting for me, and all I asked was a short, simple meet before leaving. But Khebdi decided not to show up—I waited, texted, called, and stared at my phone like a fool while you gave me pure silence. Because of you, I missed that flight, lost the job, and my entire career ended up in the trash. I hope you’re proud of your contribution to my downfall, Chudail, because it will truly never be forgotten.

And yet, somehow, you’re still my best friend. I don’t understand how that logic works either—you’re moody, late, impossible, and disappear whenever it suits you, but when you’re around, things just feel a little less heavy. So happy birthday, Faudi. Grow up a little this year, or don’t—just try answering your phone next time someone is waiting for you with their entire future in their hands, because one victim is enough.

Yours,

still somehow stuck with you,
Asif`,

  // Add photos to assets/images/. Add or remove items freely.
  memories: [
    { image: "assets/images/img1.jpeg", alt: "Shaima and Asif at Juhu beach",
      caption: "Juhu beach. After a very long argument, we finally met and found some peace.😌" },
    { image: "assets/images/img3.jpeg", alt: "Unexpected childhood pic you sent me",
      caption: "Unexpected childhood pic you sent me.😅" },
    { image: "assets/images/img5.jpeg", alt: "The trend we try with our pics",
      caption: "The trend we try with our pics.🌚😎" },
    { image: "assets/images/img6.jpeg", alt: "teasing you with a photo of your own",
      caption: "Stolen from your Snapchat.🤣🤣" },
    { image: "assets/images/img2.jpeg", alt: "A dare!",
      caption: "A Only dare you Completed!🥱"}
  ],

  // Add songs to assets/audio/. "art" is optional (image path).
  songs: [
     { title: "[MAAND]", artist: "[ARTIST: FAUDI]", src: "assets/audio/song.mp3", art: "" }

  ],

  // type: "video" | "photo" | "message". "message" shows under any type.
  secret: {
    type: "video",
    src: "assets/video/surprise.mp4",
    alt: "A special photo",
    message: "SKINCARE TIP YOU GAVE ME...🤣🤣"
  },

  finalMessage: [
    
    "I hope this year gives you everything you’re wishing for.",
    "Stay exactly the way you are."
  ]
};
