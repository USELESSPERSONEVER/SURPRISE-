(() => {
  "use strict";
  const cfg = window.birthdayConfig;
  if (!cfg) return console.error("config.js did not load.");

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const body = document.body;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const behavior = reduce ? "auto" : "smooth";
  // Add ?preview to the URL to skip the countdown while testing.
  const unlockAt = new URLSearchParams(location.search).has("preview") ? 0 : new Date(cfg.unlockAt).getTime();
  const isOpen = () => !(unlockAt > Date.now());
  const BG_VOL = 10;
  let started = false, musicOn = true, current = null;

  $$("[data-name]").forEach(e => (e.textContent = cfg.name));
  $$("[data-nick]").forEach(e => (e.textContent = cfg.nickname));
  $$("[data-you]").forEach(e => (e.textContent = cfg.yourName));
  cfg.finalMessage.forEach((t, i) => { const p = $(`[data-final="${i}"]`); if (p) p.textContent = t; });

  const missing = (el, path) => {
    const d = document.createElement("div");
    d.className = "ph";
    d.textContent = "Add file: " + path;
    el.replaceWith(d);
  };

  /* Background particles */
  const cv = $("#bg"), ctx = cv.getContext("2d");
  let W = 0, H = 0, dots = [];
  function sizeCanvas() {
    const r = devicePixelRatio || 1;
    W = innerWidth; H = innerHeight;
    cv.width = W * r; cv.height = H * r;
    ctx.setTransform(r, 0, 0, r, 0, 0);
    dots = Array.from({ length: Math.min(45, Math.round(W * H / 26000) + 12) }, () => ({
      x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.6 + 0.4,
      vx: (Math.random() - 0.5) * 0.08, vy: -(Math.random() * 0.15 + 0.03), a: Math.random() * 0.5 + 0.2
    }));
  }
  function draw() {
    ctx.clearRect(0, 0, W, H);
    ctx.shadowColor = "#a78bfa"; ctx.shadowBlur = 6;
    for (const d of dots) {
      d.x += d.vx; d.y += d.vy;
      if (d.y < -5) { d.y = H + 5; d.x = Math.random() * W; }
      ctx.beginPath(); ctx.arc(d.x, d.y, d.r, 0, 6.283);
      ctx.fillStyle = `rgba(203,184,255,${d.a})`; ctx.fill();
    }
    if (!reduce) requestAnimationFrame(draw);
  }
  let lastW = innerWidth;
  sizeCanvas(); draw();
  addEventListener("resize", () => { if (innerWidth !== lastW) { lastW = innerWidth; sizeCanvas(); } });

  /* Audio */
  const bgm = $("#bgm");
  bgm.src = cfg.backgroundMusic;
  function fadeTo(a, v, ms = 1500) {
    clearInterval(a._f);
    const from = a.volume, steps = Math.max(1, ms / 50);
    let i = 0;
    a._f = setInterval(() => {
      i++;
      a.volume = Math.min(1, Math.max(0, from + (v - from) * i / steps));
      if (i >= steps) { clearInterval(a._f); if (v === 0) a.pause(); }
    }, 50);
  }
  function startMusic() {
    if (bgm.paused) bgm.volume = 0;
    bgm.play().then(() => fadeTo(bgm, BG_VOL)).catch(() => {});
  }
  const duck = v => { if (musicOn && !bgm.paused) fadeTo(bgm, v); };
  const resumeBg = () => { if (started && musicOn && !current) startMusic(); };

  $("#musicBtn").addEventListener("click", e => {
    musicOn = !musicOn;
    e.currentTarget.classList.toggle("off", !musicOn);
    e.currentTarget.setAttribute("aria-pressed", String(musicOn));
    if (musicOn) resumeBg(); else fadeTo(bgm, 0);
  });

  /* Scroll reveal (also drives the final tulip via .scene) */
  const paper = $("#paper"), letterEl = $("#letterText");
  let typed = false, typeTimer;
  const io = new IntersectionObserver(entries => entries.forEach(e => {
    e.target.classList.toggle("in", e.isIntersecting);
    if (e.isIntersecting && e.target === paper) setTimeout(typeLetter, 1200);
  }), { threshold: 0.25 });
  $$(".reveal,.scene").forEach(el => io.observe(el));

  /* Letter */
  $("#letterSr").textContent = cfg.letter;
  function typeLetter() {
    if (typed) return;
    typed = true;
    const text = cfg.letter;
    if (reduce) { letterEl.textContent = text; paper.classList.add("done"); return; }
    let i = 0;
    const step = () => {
      i++;
      letterEl.textContent = text.slice(0, i);
      if (i >= text.length) { paper.classList.add("done"); return; }
      const c = text[i - 1];
      typeTimer = setTimeout(step, ".,!?…".includes(c) ? 260 : c === "\n" ? 320 : 40);
    };
    step();
  }
  function resetLetter() {
    clearTimeout(typeTimer); typed = false;
    letterEl.textContent = ""; paper.classList.remove("done");
  }

  /* Memories */
  const tilts = [-2.5, 1.8, -1.2, 2.2];
  cfg.memories.forEach((m, i) => {
    const fig = document.createElement("figure");
    fig.className = "photo reveal"; fig.tabIndex = 0;
    fig.style.setProperty("--rot", tilts[i % tilts.length] + "deg");
    const img = new Image();
    img.src = m.image; img.alt = m.alt || m.caption; img.loading = "lazy"; img.decoding = "async";
    img.addEventListener("error", () => missing(img, m.image), { once: true });
    const cap = document.createElement("figcaption");
    cap.textContent = m.caption;
    fig.append(img, cap);
    fig.addEventListener("click", () => fig.classList.toggle("active"));
    $("#memList").append(fig); io.observe(fig);
  });

  /* Songs */
  function toggleSong(audio) {
    if (!audio.paused) { audio.pause(); return; }
    if (current && current !== audio) current.pause();
    current = audio;
    fadeTo(bgm, 0);
    audio.play().catch(() => {});
  }
  cfg.songs.forEach(s => {
    const card = document.createElement("article");
    card.className = "song reveal";
    const art = document.createElement("div");
    art.className = "art"; art.setAttribute("aria-hidden", "true");
    if (s.art) { const i = new Image(); i.src = s.art; i.alt = ""; i.loading = "lazy"; art.append(i); } else art.textContent = "♪";
    const info = document.createElement("div");
    const h = document.createElement("h3"); h.textContent = s.title;
    const a = document.createElement("p"); a.className = "artist"; a.textContent = s.artist;
    const n = document.createElement("p"); n.className = "note"; n.textContent = s.note;
    info.append(h, a, n);
    const btn = document.createElement("button");
    btn.type = "button"; btn.className = "play"; btn.textContent = "▶"; btn.setAttribute("aria-label", "Play " + s.title);
    const audio = new Audio();
    audio.preload = "none"; audio.src = s.src;
    const stopped = () => {
      card.classList.remove("playing"); btn.textContent = "▶";
      if (current === audio) { current = null; resumeBg(); }
    };
    btn.addEventListener("click", () => toggleSong(audio));
    audio.addEventListener("play", () => { card.classList.add("playing"); btn.textContent = "❚❚"; });
    audio.addEventListener("pause", stopped);
    audio.addEventListener("ended", stopped);
    audio.addEventListener("error", () => { stopped(); btn.disabled = true; btn.title = "Add " + s.src; });
    card.append(art, info, btn);
    $("#songList").append(card); io.observe(card);
  });

  /* Secret surprise */
  const overlay = $("#overlay"), openBtn = $("#openBtn"), box = $("#secretContent");
  function buildSecret() {
    const s = cfg.secret;
    box.replaceChildren();
    if (s.type === "video") {
      const v = document.createElement("video");
      v.src = s.src; v.controls = true; v.playsInline = true; v.preload = "metadata";
      v.addEventListener("error", () => missing(v, s.src), { once: true });
      box.append(v);
    } else if (s.type === "photo") {
      const img = new Image();
      img.src = s.src; img.alt = s.alt || "A special photo";
      img.addEventListener("error", () => missing(img, s.src), { once: true });
      box.append(img);
    }
    if (s.message) { const p = document.createElement("p"); p.textContent = s.message; box.append(p); }
  }
  function closeSecret(reset) {
    const v = $("video", box);
    if (v) v.pause();
    overlay.classList.remove("show");
    body.classList.remove("dim");
    duck(BG_VOL);
    if (reset) openBtn.classList.remove("open");
  }
  openBtn.addEventListener("click", () => {
    if (openBtn.classList.contains("open")) return;
    buildSecret();
    duck(0.08);
    body.classList.add("dim");
    openBtn.classList.add("open");
    setTimeout(() => { overlay.classList.add("show"); $("#closeBtn").focus({ preventScroll: true }); }, reduce ? 0 : 1600);
  });
  $("#closeBtn").addEventListener("click", () => {
    closeSecret(false);
    $("#final").scrollIntoView({ behavior });
  });

  /* Replay */
  $("#replay").addEventListener("click", () => {
    resetLetter();
    closeSecret(true);
    $$(".photo.active").forEach(f => f.classList.remove("active"));
    scrollTo({ top: 0, behavior });
  });

  /* Countdown gate */
  const gate = $("#gate"), beginBtn = $("#beginBtn");
  const pad = n => String(n).padStart(2, "0");
  function tick() {
    const s = isOpen() ? 0 : Math.ceil((unlockAt - Date.now()) / 1000);
    $('[data-u="h"]').textContent = pad(Math.floor(s / 3600));
    $('[data-u="m"]').textContent = pad(Math.floor(s % 3600 / 60));
    $('[data-u="s"]').textContent = pad(s % 60);
    if (s === 0) { clearInterval(timerId); ready(); }
  }
  function ready() {
    $("#gateTitle").textContent = "It’s time.";
    $("#gateLine").textContent = `Happy birthday, ${cfg.name}. Ready?`;
    $("#timer").hidden = true;
    $("#gateSmall").hidden = true;
    beginBtn.hidden = false;
  }
  const timerId = setInterval(tick, 1000);
  tick();

  beginBtn.addEventListener("click", () => {
    started = true;
    startMusic();
    $("#musicBtn").hidden = false;
    gate.classList.add("out");
    setTimeout(() => {
      gate.hidden = true;
      $("#story").hidden = false;
      body.classList.remove("locked");
      scrollTo(0, 0);
    }, reduce ? 0 : 700);
  });
})();
