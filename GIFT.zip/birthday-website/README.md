# Birthday website

Plain HTML/CSS/JS. No build step.

## Edit
Everything personal lives in `config.js`: letter, captions, songs, secret type, final message.

## Add your files
- Photos: `assets/images/memory1.jpg`, `memory2.jpg`, `memory3.jpg` (resize to ~1200px wide, under 400 KB each)
- Music: `assets/audio/background.mp3`, `song1.mp3` to `song3.mp3`
- Secret video: `assets/video/surprise.mp4` (compress to 720p, keep it small)
Missing files show a "Add file: path" box instead of breaking.

## Test
Open `index.html?preview` to skip the countdown. Without `?preview` it stays locked until 12:00 AM IST, 29 Sept 2026.
Run it through a local server or your host, not by double-clicking, for the most reliable audio and video.

## Deploy
Drag the whole folder onto Netlify Drop (app.netlify.com/drop), or use Cloudflare Pages / GitHub Pages. Send her the link.

## Known limits
- The countdown uses the visitor's device clock. It is a surprise gate, not security.
- iPhone Safari ignores JavaScript volume control, so music fades do not work there and volume follows the phone.
